﻿using UnityEngine;
using System.Collections;
using System;
using SimpleJSON;

public class wsScript : MonoBehaviour {

	WebSocket w;

	// Use this for initialization
	IEnumerator Start () {
		w = new WebSocket(new Uri("ws://46.101.102.181:8080"));
		yield return StartCoroutine(w.Connect());
		//w.SendString("Hi there");
//		int i=0;
//		while (true)
//		{

			
//		}
//		w.Close();
		yield return 0;
	}

	void Update() {
		string reply = w.RecvString();
		if (reply != null) {
			//Debug.Log (reply);
			//w.SendString("Hi thsere"+i++);
			var N = JSON.Parse(reply);
							if (N != null) {
								string type = N["type"];
								Debug.Log (type);
//								if (type == "move" || type == "zoom") {
			transform.Rotate (Vector3.up);
			//					}
							}
		}
		if (w.error != null) {
			Debug.LogError ("Error: " + w.error);
//			break;
		}
//		yield return 0;
	}
}
